﻿using DogMeatStore.DataAccess.Entities;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace DogMeatStore.DataAccess
{
    public class DogMeatStoreContext : IdentityDbContext<User>
    {
        public DogMeatStoreContext(DbContextOptions<DogMeatStoreContext> options)
            : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            builder.Entity<Dish>(eb =>
            {
                eb.Ignore(dish => dish.Quantity);
            });
            //builder.Entity<DishesOrdersMapping>(eb =>
            //{
            //    eb.HasNoKey();
            //});
            // Customize the ASP.NET Identity model and override the defaults if needed.
            // For example, you can rename the ASP.NET Identity table names and more.
            // Add your customizations after calling base.OnModelCreating(builder);
        }

        public virtual DbSet<Store> Stores { get; set; }
        public virtual DbSet<Order> Orders { get; set; }
        public virtual DbSet<Dish> Dishes { get; set; }
        public virtual DbSet<DishesOrdersMapping> DishesOrdersMappings { get; set; }
        public virtual DbSet<Material> Materials { get; set; }
    }
}
