﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace DogMeatStore.DataAccess.Entities
{
    public class Order
    {
        public int Id { get; set; }
        [Column(TypeName = "smallint")]
        public int CustomerSize { get; set; }
        public DateTime OrderTime { get; set; }
        public int StoreId { get; set; }
        public DateTime CreatedTime { get; set; }
        [Column(TypeName = "smallint")]
        public int Status { get; set; }
    }
}
