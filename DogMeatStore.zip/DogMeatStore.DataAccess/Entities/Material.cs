﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DogMeatStore.DataAccess.Entities
{
    public class Material
    {
        public int Id { get; set; }
        public string MaterialName { get; set; }
        public string Unit { get; set; }
        public int Quantity { get; set; }
        public DateTime ReceivedTime { get; set; }
        public int StoreId { get; set; }
        [Column(TypeName = "numeric(18,2)")]
        public decimal TotalCost { get; set; }
    }
}
