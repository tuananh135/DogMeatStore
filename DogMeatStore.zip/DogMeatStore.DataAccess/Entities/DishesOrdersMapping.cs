﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DogMeatStore.DataAccess.Entities
{
    public class DishesOrdersMapping
    {
        public int Id { get; set; }
        public int DishId { get; set; }
        public int OrderId { get; set; }
        public int Quantity { get; set; }
    }
}
