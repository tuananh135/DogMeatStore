﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace DogMeatStore.DataAccess.Entities
{
    public class Store
    {   
        public int Id { get; set; }
        public string StoreName { get; set; }
        public string StoreAddress { get; set; }
        public float Latitude { get; set; }
        public float Longtitude { get; set; }
        public bool IsActive { get; set; }
    }
}
