﻿using System.ComponentModel;

namespace DogMeatStore.Utilities.Enums
{
    public enum EnumStatusOfBooking
    {
        Pending,
        Accepted,
        Denied
    }
}
