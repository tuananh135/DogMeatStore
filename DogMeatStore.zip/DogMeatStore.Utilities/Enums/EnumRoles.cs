﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DogMeatStore.Utilities.Enums
{
    public enum EnumRoles
    {
        StoreManagement,
        Admin
    }
}
