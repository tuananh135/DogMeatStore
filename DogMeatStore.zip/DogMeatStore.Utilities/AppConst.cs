﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DogMeatStore.Utilities
{
    public class AppConst
    {
        public const string ConnectionName = "DogMeatStoreContextConnection";
    }
}
