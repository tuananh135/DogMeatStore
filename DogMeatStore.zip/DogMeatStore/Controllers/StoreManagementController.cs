﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using DogMeatStore.DataAccess.Entities;
using DogMeatStore.Models;
using DogMeatStore.Services.Interfaces;
using DogMeatStore.Utilities.Enums;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace DogMeatStore.Controllers
{
    public class StoreManagementController : Controller
    {
        private readonly UserManager<User> _userManager;
        private readonly IOrderService _orderService;
        private readonly IMapper _mapper;
        public StoreManagementController(IOrderService orderService, UserManager<User> userManager, IMapper mapper)
        {
            _orderService = orderService;
            _userManager = userManager;
            _mapper = mapper;
        }
        [Authorize]
        public async Task<IActionResult> Index()
        {
            var identity = await _userManager.GetUserAsync(HttpContext.User);
            var orders = await _orderService.GetOrdersByStoreIdAsync(identity.StoreId ?? 0);
            var ordersModel = _mapper.Map<IList<OrderModel>>(orders);
            return View(ordersModel);
        }
    }
}