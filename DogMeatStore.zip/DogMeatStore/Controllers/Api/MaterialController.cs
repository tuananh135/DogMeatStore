﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using DogMeatStore.Models;
using DogMeatStore.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace DogMeatStore.Controllers.Api
{
    [Route("api/[controller]")]
    [ApiController]
    public class MaterialController : ControllerBase
    {
        private readonly IMapper _mapper;
        private readonly IMaterialService _materialService;
        public MaterialController(IMapper mapper, IMaterialService materialService)
        {
            _mapper = mapper;
            _materialService = materialService;
        }
        [HttpGet("received-materials-of-store/{storeId}")]
        public async Task<ObjectResult> GetReceivedMaterialsOfStoreForTheDay(DateTime date, int storeId)
        {
            var materials = await _materialService.GetReceivedMaterialsOfStoreForTheDayAsync(date, storeId);
            var materialModels = _mapper.Map<IList<MaterialModel>>(materials);
            return new OkObjectResult(materialModels);
        }
    }
}
