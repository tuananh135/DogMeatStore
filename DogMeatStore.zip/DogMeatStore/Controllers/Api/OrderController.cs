﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using DogMeatStore.DataAccess.Entities;
using DogMeatStore.Models;
using DogMeatStore.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace DogMeatStore.Controllers.Api
{
    [ApiController]
    [Route("api/[controller]")]
    public class OrderController : ControllerBase
    {
        private readonly IMapper _mapper;
        private readonly IOrderService _orderService;
        public OrderController(IMapper mapper, IOrderService orderService)
        {
            _mapper = mapper;
            _orderService = orderService;
        }

        [HttpPost("book")]
        public async Task<ObjectResult> Book([FromForm]OrderModel input)
        {
            if (!IsBookingValid(input))
            {
                ModelState.AddModelError(string.Empty, "Invalid Attempt");
                return new BadRequestObjectResult("Internal Server Error");
            }
            var order = new Order
            {
                CustomerSize = input.CustomerSize,
                OrderTime = input.OrderTime,
                StoreId = input.StoreId
            };
            bool isSuccessful = await _orderService.BookAsync(order);
            if (isSuccessful)
            {
                return new OkObjectResult("");
            }
            else
            {
                return new BadRequestObjectResult("Internal Server Error");
            }
        }
        private bool IsBookingValid(OrderModel input)
        {
            return input.CustomerSize > 0 && input.CustomerSize < 100 
                && input.OrderTime > DateTime.Now && input.StoreId > 0;
        }
        #region Order's operations
        [HttpPut("accept-booking/{id}")]
        public async Task<ObjectResult> AcceptBooking(int orderId)
        {
            if (!IsOrderIdValid(orderId))
            {
                return new BadRequestObjectResult("OrderId is not valid");
            }
            bool isSuccessful = await _orderService.AcceptBookingAsync(orderId);
            if (isSuccessful)
            {
                return new OkObjectResult("");
            }
            else
            {
                return new BadRequestObjectResult("Internal Server Error");
            }
        }
        [HttpPut("deny-booking/{id}")]
        public async Task<ObjectResult> DenyBooking([FromBody]int orderId)
        {
            if (!IsOrderIdValid(orderId))
            {
                return new BadRequestObjectResult("OrderId is not valid");
            }
            bool isSuccessful = await _orderService.DenyBookingAsync(orderId);
            if (isSuccessful)
            {
                return new OkObjectResult("");
            }
            else
            {
                return new BadRequestObjectResult("Internal Server Error");
            }
        }
        private bool IsOrderIdValid(int orderId)
        {
            return orderId > 0;
        }
        #endregion
        [HttpPost("orders-of-store/{storeId}")]
        public async Task<ObjectResult> GetOrdersByStoreId(int storeId)
        {
            var orders = await _orderService.GetOrdersByStoreIdAsync(storeId);
            var orderModels = _mapper.Map<IList<OrderModel>>(orders);
            return new ObjectResult(orderModels);
        }
    }
}