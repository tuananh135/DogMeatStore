﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using DogMeatStore.DataAccess.Entities;
using DogMeatStore.Models;
using DogMeatStore.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace DogMeatStore.Controllers.Api
{
    [Route("api/[controller]")]
    [ApiController]
    public class DishController : ControllerBase
    {
        private readonly IMapper _mapper;
        private readonly IDishService _dishService;
        public DishController(IMapper mapper, IDishService dishService)
        {
            _mapper = mapper;
            _dishService = dishService;
        }
        [HttpGet("dishes-of-order/{orderId}")]
        public async Task<ObjectResult> GetDishesOfOrderByOrderId(int orderId)
        {
            var dishes = await _dishService.GetDishesOfOrderByOrderIdAsync(orderId);
            var dishModels = _mapper.Map<IList<DishModel>>(dishes);
            return new OkObjectResult(dishModels);
        }

        [HttpGet("dishes-of-store/{storeId}")]
        public async Task<ObjectResult> GetDishesOfStoreByStoreId(int storeId)
        {
            var dishes = await _dishService.GetDishesOfStoreByStoreIdAsync(storeId);
            var dishModels = _mapper.Map<IList<DishModel>>(dishes);
            return new OkObjectResult(dishModels);
        }

        [HttpGet("cost-of-order/{orderId}")]
        public async Task<ObjectResult> GetConsumptionCostOfOrder(int orderId)
        {
            var cost = await _dishService.GetConsumptionCostOfOrderAsync(orderId);
            return new OkObjectResult(cost);
        }

        [HttpPost("add-dishes/{orderId}")]
        public async Task<ObjectResult> AddDishesToOrder(int orderId, [FromBody] IList<int> listDishId)
        {
            if (!IsValidDishes(orderId, listDishId))
            {
                return new BadRequestObjectResult("Dishes is not valid");
            }
            var isSuccessful = await _dishService.AddDishesToOrderAsync(orderId, listDishId);
            if (isSuccessful)
            {
                return new OkObjectResult("");
            }
            else
            {
                return new BadRequestObjectResult("Internal Server Error");
            }
        }

        [HttpPost("remove-dishes/{orderId}")]
        public async Task<ObjectResult> RemoveDishesFromOrder(int orderId, [FromBody] IList<int> listDishId)
        {
            if (!IsValidDishes(orderId, listDishId))
            {
                return new BadRequestObjectResult("Dishes is not valid");
            }
            var isSuccessful = await _dishService.RemoveDishesFromOrderAsync(orderId, listDishId);
            if (isSuccessful)
            {
                return new OkObjectResult("");
            }
            else
            {
                return new BadRequestObjectResult("Internal Server Error");
            }
        }
        private bool IsValidDishes(int orderId, IList<int> listDishId)
        {
            return orderId > 0 && listDishId.Any();
        }
    }
}
