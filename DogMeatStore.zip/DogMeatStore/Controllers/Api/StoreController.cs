﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AutoMapper;
using DogMeatStore.Models;
using DogMeatStore.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace DogMeatStore.Controllers.Api
{
    [Route("api/[controller]")]
    [ApiController]
    public class StoreController : ControllerBase
    {
        private readonly IMapper _mapper;
        private readonly IStoreService _storeService;
        public StoreController(IMapper mapper, IStoreService storeService)
        {
            _mapper = mapper;
            _storeService = storeService;
        }
        // GET: api/Store
        [HttpGet]
        public async Task<ObjectResult> GetAllStores()
        {
            var stores = await _storeService.GetAllStoresAsync();
            var storeModels = _mapper.Map<IList<StoreModel>>(stores);
            return new OkObjectResult(storeModels);
        }
        
        [HttpGet("revenue-for-day")]
        public async Task<ObjectResult> GetRevenueForTheDay(DateTime date)
        {
            var revenue = await _storeService.GetRevenueForTheDayAsync(date);
            return new ObjectResult(revenue);
        }

        [HttpGet("revenue-for-month")]
        public async Task<ObjectResult> GetRevenueForTheMonth(int month, int year)
        {
            var revenue = await _storeService.GetRevenueForTheMonthAsync(month, year);
            return new ObjectResult(revenue);
        }

        [HttpGet("revenue-store-for-day/{storeId}")]
        public async Task<ObjectResult> GetRevenueOfStoreForTheDay(DateTime date, int storeId)
        {
            var revenue = await _storeService.GetRevenueOfStoreForTheDayAsync(date, storeId);
            return new ObjectResult(revenue);
        }

        [HttpGet("revenue-store-for-month/{storeId}")]
        public async Task<ObjectResult> GetRevenueForTheDay(int month, int year, int storeId)
        {
            var revenue = await _storeService.GetRevenueOfStoreForTheMonthAsync(month, year, storeId);
            return new ObjectResult(revenue);
        }
    }
}
