﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using DogMeatStore.Models;
using DogMeatStore.Services.Interfaces;
using System.Threading.Tasks;
using AutoMapper;
using System.Collections.Generic;

namespace DogMeatStore.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IStoreService _storeService;
        private readonly IMapper _mapper;
        public HomeController(ILogger<HomeController> logger, IStoreService storeService, IMapper mapper)
        {
            _logger = logger;
            _storeService = storeService;
            _mapper = mapper;
        }

        public async Task<IActionResult> Index()
        {
            var stores = await _storeService.GetAllStoresAsync();
            var storesModel = _mapper.Map<List<StoreModel>>(stores);
            _logger.LogInformation("Get all stores");
            ViewData["stores"] = storesModel;
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
