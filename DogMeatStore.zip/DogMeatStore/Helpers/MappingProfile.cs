﻿using AutoMapper;
using DogMeatStore.DataAccess.Entities;
using DogMeatStore.Models;
using DogMeatStore.Utilities.Enums;
using System;

namespace DogMeatStore.Helpers
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<Store, StoreModel>();
            CreateMap<Order, OrderModel>()
                .ForMember(c => c.Status, opt => opt.MapFrom(src => (EnumStatusOfBooking)src.Status))
                .ForMember(c => c.StatusName, opt => opt.MapFrom(src => Enum.GetName(typeof(EnumStatusOfBooking), src.Status)));
            CreateMap<Dish, DishModel>();
            CreateMap<Material, MaterialModel>();
        }
    }
}
