﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DogMeatStore.Models
{
    public class DishModel
    {
        public int Id { get; set; }
        public string DishName { get; set; }
        public decimal Price { get; set; }
        public int StoreId { get; set; }
        public int Quantity { get; set; }
    }
}
