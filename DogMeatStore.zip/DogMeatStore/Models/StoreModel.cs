﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DogMeatStore.Models
{
    public class StoreModel
    {
        public int Id { get; set; }
        public string StoreName { get; set; }
        public string StoreAddress { get; set; }
        public float Latitude { get; set; }
        public float Longtitude { get; set; }
        public bool IsActive { get; set; }
    }
}
