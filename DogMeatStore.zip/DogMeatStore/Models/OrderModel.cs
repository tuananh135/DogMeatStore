﻿using DogMeatStore.Utilities.Enums;
using System;
using System.ComponentModel.DataAnnotations;

namespace DogMeatStore.Models
{
    public class OrderModel
    {
        public int Id { get; set; }
        [Required(ErrorMessage = "Please enter customers size")]
        public int CustomerSize { get; set; }
        [Required(ErrorMessage = "Please enter order time")]
        public DateTime OrderTime { get; set; }
        public int StoreId { get; set; }
        public DateTime CreatedTime { get; set; }
        public EnumStatusOfBooking Status { get; set; }
        public string StatusName { get; set; }
    }
}
