﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DogMeatStore.Models
{
    public class MaterialModel
    {
        public int Id { get; set; }
        public string MaterialName { get; set; }
        public string Unit { get; set; }
        public int Quantity { get; set; }
        public DateTime ReceivedTime { get; set; }
        public int StoreId { get; set; }
        public decimal TotalCost { get; set; }
    }
}
