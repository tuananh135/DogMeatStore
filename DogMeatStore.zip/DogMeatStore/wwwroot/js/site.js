﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.
$(".btn-pick-store").on("click", function (event) {
    $(".btn-pick-store").removeClass("active");
    event.target.classList.add("active");
    $("#StoreId").val(event.target.id);
});

function initMap() {
    const map = new google.maps.Map(document.getElementById("map"), {
        zoom: 12,
        center: { lat: -28.024, lng: 140.887 },
    });
    const infoWindow = new google.maps.InfoWindow({
        disableAutoPan: true,
    });
    navigator.geolocation.getCurrentPosition(
        (position) => {
            const pos = {
                lat: position.coords.latitude,
                lng: position.coords.longitude,
            };

            infoWindow.setPosition(pos);
            infoWindow.setContent("You are here!");
            infoWindow.open(map);
            map.setCenter(pos);
        },
        () => {
            console.log("error!")
        }
    );
    $.get("/api/store", function (stores) {
        const locations = stores.map(store => {
            return {
                lat: store.latitude,
                lng: store.longtitude
            }
        });
        const labels = stores.map(store => store.storeName);
        const storeIds = stores.map(store => store.id);
        const markers = locations.map((position, i) => {
            const marker = new google.maps.Marker({
                position,
                label: "C",
            });

            // markers can only be keyboard focusable when they have click listeners
            // open info window when marker is clicked
            marker.addListener("click", () => {
                infoWindow.setContent(labels[i]);
                infoWindow.open(map, marker);
                $(".btn-pick-store").removeClass("active");
                $(`.btn-pick-store`)[i].classList.add("active");
                $("#StoreId").val(storeIds[i]);
            });
            return marker;
        });

        // Add a marker clusterer to manage the markers.
        const markerCluster = new markerClusterer.MarkerClusterer({ markers, map });
    })
}