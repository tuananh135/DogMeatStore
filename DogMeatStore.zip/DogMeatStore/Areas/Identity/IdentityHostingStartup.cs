﻿using Microsoft.AspNetCore.Hosting;

[assembly: HostingStartup(typeof(DogMeatStore.Areas.Identity.IdentityHostingStartup))]
namespace DogMeatStore.Areas.Identity
{
    public class IdentityHostingStartup : IHostingStartup
    {
        public void Configure(IWebHostBuilder builder)
        {
            //builder.ConfigureServices((context, services) => {
            //    services.AddDbContext<DogMeatStoreContext>(options =>
            //        options.UseSqlServer(
            //            context.Configuration.GetConnectionString("DogMeatStoreContextConnection")));

            //    services.AddDefaultIdentity<DogMeatStoreUser>(options => options.SignIn.RequireConfirmedAccount = true)
            //        .AddEntityFrameworkStores<DogMeatStoreContext>();
            //});
        }
    }
}