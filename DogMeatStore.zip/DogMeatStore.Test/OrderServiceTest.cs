﻿using DogMeatStore.DataAccess;
using DogMeatStore.DataAccess.Entities;
using DogMeatStore.Services;
using DogMeatStore.Utilities.Enums;
using Microsoft.EntityFrameworkCore;
using System;
using System.Threading.Tasks;
using Xunit;

namespace DogMeatStore.Test
{
    public class OrderServiceTest : DatabaseFixture
    {
        private readonly OrderService orderService;
        private const int StoreId = 5;
        private const int OrderId = 1;
        public OrderServiceTest() : base(new DbContextOptionsBuilder<DogMeatStoreContext>()
            .UseInMemoryDatabase(databaseName: "OrderTest")
            .Options)
        {
            orderService = new OrderService(_context);
        }

        [Fact]
        public async Task GetAllOrders_Test()
        {
            //Act
            var output = await orderService.GetAllOrdersAsync();

            //Assert
            Assert.Equal(100, output.Count);
        }

        [Fact]
        public async Task GetOrdersByStoreId_Test()
        {
            //Act
            var output = await orderService.GetOrdersByStoreIdAsync(StoreId);

            //Assert
            Assert.Equal(5, output.Count);
        }

        [Fact]
        public async Task AcceptingChangeBookingToBeAccepted()
        {
            //Act
            var action = await orderService.AcceptBookingAsync(OrderId);
            var output = await orderService.GetAllOrdersAsync();

            //Assert
            Assert.Contains(output, order => order.Id == OrderId && order.Status == (int) EnumStatusOfBooking.Accepted);
        }

        [Fact]
        public async Task DenyingChangeBookingToBeDenied()
        {
            //Act
            var action = await orderService.DenyBookingAsync(OrderId);
            var output = await orderService.GetAllOrdersAsync();

            //Assert
            Assert.Contains(output, order => order.Id == OrderId && order.Status == (int)EnumStatusOfBooking.Denied);
        }
    }
}
