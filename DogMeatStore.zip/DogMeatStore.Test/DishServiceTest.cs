﻿using DogMeatStore.DataAccess;
using DogMeatStore.DataAccess.Entities;
using DogMeatStore.Services;
using DogMeatStore.Utilities.Enums;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace DogMeatStore.Test
{
    public class DishServiceTest : DatabaseFixture
    {
        private const int StoreId = 1;
        private const int OrderId = 1;
        private readonly DishService dishService;
        public DishServiceTest() : base(new DbContextOptionsBuilder<DogMeatStoreContext>()
            .UseInMemoryDatabase(databaseName: "DishTest")
            .Options)
        {
            dishService = new DishService(_context);
        }

        [Fact]
        public async Task GetDishesOfStoreByStoreId_Test()
        {
            //Act
            var output = await dishService.GetDishesOfStoreByStoreIdAsync(StoreId);

            //Assert
            Assert.Equal(4, output.Count);
        }

        [Fact]
        public async Task GetDishesOfOrderByOrderId_Test()
        {
            //Act
            var output = await dishService.GetDishesOfOrderByOrderIdAsync(OrderId);

            //Assert
            Assert.Equal(3, output.Count);
        }

        [Fact]
        public async Task GetConsumptionCostOfOrder_Test()
        {
            //Act
            var output = await dishService.GetConsumptionCostOfOrderAsync(OrderId);

            //Assert
            Assert.Equal(160000, output);
        }

        [Fact]
        public async Task AddDishesToOrder_Test()
        {
            var dishIds = new List<int>() { 4 };
            var orderId = 1;
            //Act
            await dishService.AddDishesToOrderAsync(orderId, dishIds);
            var output = await dishService.GetDishesOfOrderByOrderIdAsync(orderId);

            //Assert
            Assert.Equal(4, output.Count);
        }

        [Fact]
        public async Task RemoveDishesFromOrder_Test()
        {
            var dishIds = new List<int>() { 4 };
            var orderId = 1;
            //Act
            await dishService.RemoveDishesFromOrderAsync(orderId, dishIds);
            var output = await dishService.GetDishesOfOrderByOrderIdAsync(orderId);

            //Assert
            Assert.Equal(3, output.Count);
        }
    }
}
