﻿using DogMeatStore.DataAccess;
using DogMeatStore.DataAccess.Entities;
using DogMeatStore.Utilities.Enums;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DogMeatStore.Test
{
    public class DatabaseFixture : IDisposable
    {
        protected DbContextOptions<DogMeatStoreContext> ContextOptions { get; }
        protected DogMeatStoreContext _context;
        protected DatabaseFixture(DbContextOptions<DogMeatStoreContext> contextOptions)
        {
            ContextOptions = contextOptions;
            Seed();
        }
        private void Seed()
        {
            var rand = new Random();
            _context = new DogMeatStoreContext(ContextOptions);
            _context.Database.EnsureCreated();

            // Initilize data of dbo.Stores
            var stores = new List<Store>()
            {
               new Store(){ Id = 1, IsActive = true, Latitude = 1, Longtitude = 1, StoreAddress = "04 Duy Tân, Dịch Vọng Hậu", StoreName = "Cửa hàng thịt chó Duy Tân" },
               new Store(){ Id = 2, IsActive = true, Latitude = 1, Longtitude = 1, StoreAddress = "30 Thái Hà", StoreName = "Cửa hàng thịt chó Thái Hà" },
               new Store(){ Id = 3, IsActive = true, Latitude = 1, Longtitude = 1, StoreAddress = "129 Nguyễn Trãi, Khương Đình", StoreName = "Cửa hàng thịt chó Nguyễn Trãi" },
               new Store(){ Id = 4, IsActive = true, Latitude = 1, Longtitude = 1, StoreAddress = "02 Lương Thế Vinh, Nam Từ Liêm", StoreName = "Cửa hàng thịt chó Lương Thế Vinh" },
               new Store(){ Id = 5, IsActive = true, Latitude = 1, Longtitude = 1, StoreAddress = "173 Xuân Thủy", StoreName = "Cửa hàng thịt chó Xuân Thủy" },
               new Store(){ Id = 6, IsActive = false, Latitude = 1, Longtitude = 1, StoreAddress = "69 Tây Hồ", StoreName = "Cửa hàng thịt chó Tây Hồ" }
            };
            _context.Stores.AddRange(stores);
            // Initilize data of dbo.Orders
            var orders = new List<Order>();
            for (int i = 1; i <= 100; i++)
            {
                var order = new Order()
                {
                    Id = i,
                    CreatedTime = DateTime.Now,
                    OrderTime = DateTime.Now.AddHours(rand.Next(2, 5)),
                    CustomerSize = rand.Next(5, 11),
                    Status = i < 96 ? (int)EnumStatusOfBooking.Pending : (int)EnumStatusOfBooking.Accepted,
                    StoreId = i < 96 ? rand.Next(1, 5) : 5
                };
                orders.Add(order);
            }
            _context.Orders.AddRange(orders);
            // Initilize data of dbo.Dishes
            for (int i = 1; i <= 5; i++)
            {
                var dishes = new List<Dish>()
                {
                    new Dish(){ Id = (i - 1)*4 + 1, DishName = "Chó nướng", Price = 50000, StoreId = i },
                    new Dish(){ Id = (i - 1)*4 + 2, DishName = "Nòng nuộc", Price = 60000, StoreId = i },
                    new Dish(){ Id = (i - 1)*4 + 3, DishName = "Giả cầy", Price = 50000, StoreId = i },
                    new Dish(){ Id = (i - 1)*4 + 4, DishName = "Dồi chó", Price = 60000, StoreId = i }
                };
                _context.Dishes.AddRange(dishes);
            }
            // Initilize data of dbo.DishesOrdersMapping
            for (int i = 1; i <= 100; i++)
            {
                int storeId = orders[i - 1].StoreId;

                var mappings = new List<DishesOrdersMapping>()
                {
                    new DishesOrdersMapping(){ DishId = (storeId - 1)*4 + 1, OrderId = i, Quantity = rand.Next(1, 5) },
                    new DishesOrdersMapping(){ DishId = (storeId - 1)*4 + 2, OrderId = i, Quantity = rand.Next(1, 5) },
                    new DishesOrdersMapping(){ DishId = (storeId - 1)*4 + (i < 96 ? 3 : 4), OrderId = i, Quantity = rand.Next(1, 5) }
                };
                _context.DishesOrdersMappings.AddRange(mappings);
            }
            // Initilize data of dbo.Materials
            for (int i = 1; i <= 5; i++)
            {
                var materials = new List<Material>()
                {
                    new Material(){
                        Id = (i - 1)*4 + 1,
                        MaterialName = "Xả",
                        Quantity = rand.Next(1, 5),
                        ReceivedTime = DateTime.Now.AddHours(rand.Next(-5, -2)),
                        StoreId = i,
                        TotalCost = 10000,
                        Unit = "bó"
                    },
                    new Material(){
                        Id = (i - 1)*4 + 2,
                        MaterialName = "Gừng",
                        Quantity = rand.Next(1, 5),
                        ReceivedTime = DateTime.Now.AddHours(rand.Next(-5, -2)),
                        StoreId = i,
                        TotalCost = 15000,
                        Unit = "củ"
                    },
                    new Material(){
                        Id = (i - 1)*4 + 3,
                        MaterialName = "Chó",
                        Quantity = rand.Next(1, 5),
                        ReceivedTime = DateTime.Now.AddHours(rand.Next(-5, -2)),
                        StoreId = i,
                        TotalCost = 50000,
                        Unit = "con"
                    },
                    new Material(){
                        Id = (i - 1)*4 + 4,
                        MaterialName = "Rau sống",
                        Quantity = rand.Next(1, 5),
                        ReceivedTime = DateTime.Now.AddHours(rand.Next(-5, -2)),
                        StoreId = i,
                        TotalCost = 5000,
                        Unit = "bó"
                    },
                };
                _context.Materials.AddRange(materials);
            }
            _context.SaveChanges();
        }

        public void Dispose()
        {
            _context.Database.EnsureDeleted();
            _context.Dispose();
        }
    }
}
