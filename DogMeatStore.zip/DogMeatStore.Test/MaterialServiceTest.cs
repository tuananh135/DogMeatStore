﻿using DogMeatStore.DataAccess;
using DogMeatStore.Services;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using Xunit;
using Shouldly;
using System;

namespace DogMeatStore.Test
{
    public class MaterialServiceTest : DatabaseFixture
    {
        private readonly MaterialService materialService;
        private readonly DateTime Time = DateTime.Now;
        private const int StoreId = 1;
        public MaterialServiceTest() : base(new DbContextOptionsBuilder<DogMeatStoreContext>()
            .UseInMemoryDatabase(databaseName: "MaterialTest")
            .Options)
        {
            materialService = new MaterialService(_context);
        }

        [Fact]
        public async Task GetReceivedMaterialsOfStoreForTheDay_Test()
        {
            //Act
            var output = await materialService.GetReceivedMaterialsOfStoreForTheDayAsync(Time, StoreId);

            //Assert
            output.Count.ShouldBe(4);
        }
    }
}
