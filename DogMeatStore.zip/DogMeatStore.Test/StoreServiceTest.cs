using DogMeatStore.DataAccess;
using DogMeatStore.Services;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using Xunit;
using Shouldly;
using System;

namespace DogMeatStore.Test
{
    public class StoreServiceTest : DatabaseFixture
    {
        private readonly DateTime Time = DateTime.Now;
        private const int StoreId = 5;
        private readonly StoreService storeService;
        public StoreServiceTest() : base(new DbContextOptionsBuilder<DogMeatStoreContext>()
            .UseInMemoryDatabase(databaseName: "StoreTest")
            .Options)
        {
            storeService = new StoreService(_context);
        }

        [Fact]
        public async Task GetAllStores_Test()
        {
            //Act
            var output = await storeService.GetAllStoresAsync();

            //Assert
            output.Count.ShouldBe(5);
        }

        [Fact]
        public async Task GetRevenueForTheDay_Test()
        {
            var output = await storeService.GetRevenueForTheDayAsync(Time);

            output.ShouldBeGreaterThan(170000m * 5);
        }

        [Fact]
        public async Task GetRevenueForTheMonth_Test()
        {
            var month = 11;
            var year = 2021;
            var output = await storeService.GetRevenueForTheMonthAsync(month, year);

            output.ShouldBeGreaterThan(170000m * 5);
        }

        [Fact]
        public async Task GetRevenueOfStoreForTheMonth_Test()
        {
            var month = 11;
            var year = 2021;
            var output = await storeService.GetRevenueOfStoreForTheMonthAsync(month, year, StoreId);

            output.ShouldBeGreaterThan(170000m * 5);
        }

        [Fact]
        public async Task GetRevenueOfStoreForTheDay_Test()
        {
            var output = await storeService.GetRevenueOfStoreForTheDayAsync(Time, StoreId);

            output.ShouldBeGreaterThan(170000m * 5);
        }
    }
}
