﻿using DogMeatStore.DataAccess;
using DogMeatStore.DataAccess.Entities;
using DogMeatStore.Services.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DogMeatStore.Services
{
    public class DishService : BaseService, IDishService
    {
        public DishService(DogMeatStoreContext dbContext) : base(dbContext)
        {

        }
        public async Task<IList<Dish>> GetDishesOfStoreByStoreIdAsync(int storeId)
        {
            var query = _dbContext.Dishes.Where(dish => dish.StoreId == storeId);
            var dishes = await query.ToListAsync();
            return dishes;
        }
        public async Task<IList<Dish>> GetDishesOfOrderByOrderIdAsync(int orderId)
        {
            var query = _dbContext.DishesOrdersMappings
                        .Where(mapping => mapping.OrderId == orderId)
                        .Join(_dbContext.Dishes,
                               mapping => mapping.DishId,
                               dish => dish.Id,
                               (mapping, dish) => new Dish
                               {
                                   DishName = dish.DishName,
                                   Quantity = mapping.Quantity,
                                   Id = dish.Id,
                                   Price = dish.Price,
                                   StoreId = dish.StoreId
                               })
                        .GroupBy(dish => new { dish.Id, dish.DishName, dish.StoreId })
                        .Select(group => new Dish
                        {
                            DishName = group.Key.DishName,
                            Id = group.Key.Id,
                            Price = group.Sum(dish => dish.Price * dish.Quantity) ?? 0,
                            Quantity = group.Sum(dish => dish.Quantity),
                            StoreId = group.Key.StoreId
                        });
            var dishes = await query.ToListAsync();
            return dishes;
        }
        public async Task<decimal> GetConsumptionCostOfOrderAsync(int orderId)
        {
            var query = _dbContext.DishesOrdersMappings
                        .Where(mapping => mapping.OrderId == orderId)
                        .Join(_dbContext.Dishes,
                               mapping => mapping.DishId,
                               dish => dish.Id,
                               (mapping, dish) => new Dish
                               {
                                   DishName = dish.DishName,
                                   Quantity = mapping.Quantity,
                                   Id = dish.Id,
                                   Price = dish.Price,
                                   StoreId = dish.StoreId
                               })
                        .GroupBy(dish => new { dish.Id, dish.DishName, dish.StoreId })
                        .Select(group => new Dish
                        {
                            DishName = group.Key.DishName,
                            Id = group.Key.Id,
                            Price = group.Sum(dish => dish.Price * dish.Quantity) ?? 0,
                            Quantity = group.Sum(dish => dish.Quantity),
                            StoreId = group.Key.StoreId
                        });
            var cost = await query.SumAsync(dish => dish.Price);
            return cost;
        }
        public async Task<bool> AddDishesToOrderAsync(int orderId, IList<int> listDistId)
        {
            try
            {
                var mappings = listDistId.Select(dishId => new DishesOrdersMapping()
                {
                    DishId = dishId,
                    OrderId = orderId
                }).ToList();
                await _dbContext.DishesOrdersMappings.AddRangeAsync(mappings);
                await _dbContext.SaveChangesAsync();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public async Task<bool> RemoveDishesFromOrderAsync(int orderId, IList<int> listDistId)
        {
            try
            {
                var mappings = await _dbContext.DishesOrdersMappings
                    .Where(mapping => mapping.OrderId == orderId && listDistId.Contains(mapping.DishId))
                    .ToListAsync();
                _dbContext.DishesOrdersMappings.RemoveRange(mappings);
                await _dbContext.SaveChangesAsync();
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
