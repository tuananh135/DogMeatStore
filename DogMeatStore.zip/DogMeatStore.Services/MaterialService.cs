﻿using DogMeatStore.DataAccess;
using DogMeatStore.DataAccess.Entities;
using DogMeatStore.Services.Interfaces;
using DogMeatStore.Utilities.Enums;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DogMeatStore.Services
{
    public class MaterialService : BaseService, IMaterialService
    {
        public MaterialService(DogMeatStoreContext dbContext) : base(dbContext)
        {

        }
        public async Task<IList<Material>> GetReceivedMaterialsOfStoreForTheDayAsync(DateTime time, int storeId)
        {
            var query = _dbContext.Materials
                .Where(material => material.ReceivedTime.Date == time.Date && material.StoreId == storeId);
            var materials = await query.ToListAsync();
            return materials;
        } 
    }
}
