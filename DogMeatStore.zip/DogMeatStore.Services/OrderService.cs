﻿using DogMeatStore.DataAccess;
using DogMeatStore.DataAccess.Entities;
using DogMeatStore.Services.Interfaces;
using DogMeatStore.Utilities.Enums;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DogMeatStore.Services
{
    public class OrderService : BaseService, IOrderService
    {
        public OrderService(DogMeatStoreContext dbContext) : base(dbContext)
        {

        }
        public async Task<bool> BookAsync(Order order)
        {
            order.Status = (int) EnumStatusOfBooking.Pending;
            order.CreatedTime = DateTime.Now;
            try
            {
                await _dbContext.Orders.AddAsync(order);
                await _dbContext.SaveChangesAsync();
                return true;
            }
            catch 
            {
                return false;
            }
        }

        public async Task<IList<Order>> GetOrdersByStoreIdAsync(int storeId)
        {
            try
            {
                var query = _dbContext.Orders.Where(order => order.StoreId == storeId && order.OrderTime >= DateTime.Now).OrderBy(order => order.CreatedTime);
                var orders = await query.ToListAsync();
                return orders;
            }
            catch
            {
                return new List<Order>();
            }
        }
        public async Task<IList<Order>> GetAllOrdersAsync()
        {
            try
            {
                var query = _dbContext.Orders.Where(order => order.OrderTime >= DateTime.Now).OrderBy(order => order.CreatedTime);
                var orders = await query.ToListAsync();
                return orders;
            }
            catch
            {
                return new List<Order>();
            }
        }
        public async Task<bool> AcceptBookingAsync(int orderId)
        {
            try
            {
                var order = await _dbContext.Orders.FirstOrDefaultAsync(order => order.Id == orderId);
                order.Status = (int) EnumStatusOfBooking.Accepted;
                _dbContext.Orders.Update(order);
                await _dbContext.SaveChangesAsync();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public async Task<bool> DenyBookingAsync(int orderId)
        {
            try
            {
                var order = await _dbContext.Orders.FirstOrDefaultAsync(order => order.Id == orderId);
                order.Status = (int)EnumStatusOfBooking.Denied;
                _dbContext.Orders.Update(order);
                await _dbContext.SaveChangesAsync();
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
