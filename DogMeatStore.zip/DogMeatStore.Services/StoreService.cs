﻿using DogMeatStore.Services.Interfaces;
using DogMeatStore.DataAccess.Entities;
using System.Collections.Generic;
using DogMeatStore.DataAccess;
using System.Threading.Tasks;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using System;
using DogMeatStore.Utilities.Enums;

namespace DogMeatStore.Services
{
    public class StoreService : BaseService, IStoreService
    {
        public StoreService(DogMeatStoreContext dbContext) : base(dbContext)
        {
        }
        public async Task<IList<Store>> GetAllStoresAsync()
        {
            var stores = await _dbContext.Stores.Where(store => store.IsActive).ToListAsync();
            return stores;
        }
        public async Task<decimal> GetRevenueOfStoreForTheDayAsync(DateTime time, int storeId)
        {
            var acceptedOrdersOfStoreForTheDay = await _dbContext.Orders
                .Where(order => order.StoreId == storeId && order.OrderTime.Date == time.Date
                && order.Status == (int)EnumStatusOfBooking.Accepted).Select(order => order.Id).ToListAsync();

            var revenue = await _dbContext.DishesOrdersMappings
                .Where(mapping => acceptedOrdersOfStoreForTheDay.Contains(mapping.OrderId))
                .Join(_dbContext.Dishes,
                mapping => mapping.DishId,
                dish => dish.Id,
                (mapping, dish) => new
                {
                    Price = dish.Price * mapping.Quantity
                }).SumAsync(dish => dish.Price);
            return revenue;
        }
        public async Task<decimal> GetRevenueForTheDayAsync(DateTime time)
        {
            var acceptedOrdersForTheDay = await _dbContext.Orders
                .Where(order => order.OrderTime.Date == time.Date
                && order.Status == (int)EnumStatusOfBooking.Accepted).Select(order => order.Id).ToListAsync();

            var revenue = await _dbContext.DishesOrdersMappings
                .Where(mapping => acceptedOrdersForTheDay.Contains(mapping.OrderId))
                .Join(_dbContext.Dishes,
                mapping => mapping.DishId,
                dish => dish.Id,
                (mapping, dish) => new
                {
                    Price = dish.Price * mapping.Quantity
                }).SumAsync(dish => dish.Price);
            return revenue;
        }
        public async Task<decimal> GetRevenueOfStoreForTheMonthAsync(int month, int year, int storeId)
        {
            var acceptedOrdersOfStoreForTheMonth = await _dbContext.Orders
                .Where(order => order.StoreId == storeId && order.OrderTime.Year == year && order.OrderTime.Month == month
                && order.Status == (int)EnumStatusOfBooking.Accepted).Select(order => order.Id).ToListAsync();

            var revenue = await _dbContext.DishesOrdersMappings
                .Where(mapping => acceptedOrdersOfStoreForTheMonth.Contains(mapping.OrderId))
                .Join(_dbContext.Dishes,
                mapping => mapping.DishId,
                dish => dish.Id,
                (mapping, dish) => new
                {
                    Price = dish.Price * mapping.Quantity
                }).SumAsync(dish => dish.Price);
            return revenue;
        }
        public async Task<decimal> GetRevenueForTheMonthAsync(int month, int year)
        {
            var acceptedOrdersForTheMonth = await _dbContext.Orders
                .Where(order => order.OrderTime.Month == month && order.OrderTime.Year == year
                && order.Status == (int)EnumStatusOfBooking.Accepted).Select(order => order.Id).ToListAsync();

            var revenue = await _dbContext.DishesOrdersMappings
                .Where(mapping => acceptedOrdersForTheMonth.Contains(mapping.OrderId))
                .Join(_dbContext.Dishes,
                mapping => mapping.DishId,
                dish => dish.Id,
                (mapping, dish) => new
                {
                    Price = dish.Price * mapping.Quantity
                }).SumAsync(dish => dish.Price);
            return revenue;
        }
    }
}
