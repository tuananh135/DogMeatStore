﻿using DogMeatStore.DataAccess;

namespace DogMeatStore.Services
{
    public class BaseService
    {
        protected DogMeatStoreContext _dbContext;
        protected BaseService(DogMeatStoreContext dbContext)
        {
            _dbContext = dbContext;
        }
    }
}
