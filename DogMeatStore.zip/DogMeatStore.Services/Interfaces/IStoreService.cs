﻿using DogMeatStore.DataAccess.Entities;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DogMeatStore.Services.Interfaces
{
    public interface IStoreService
    {
        Task<IList<Store>> GetAllStoresAsync();
        Task<decimal> GetRevenueOfStoreForTheDayAsync(DateTime time, int storeId);
        Task<decimal> GetRevenueForTheDayAsync(DateTime time);
        Task<decimal> GetRevenueForTheMonthAsync(int month, int year);
        Task<decimal> GetRevenueOfStoreForTheMonthAsync(int month, int year, int storeId);
    }
}
