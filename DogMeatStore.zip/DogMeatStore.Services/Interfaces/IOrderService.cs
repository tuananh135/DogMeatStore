﻿using DogMeatStore.DataAccess.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DogMeatStore.Services.Interfaces
{
    public interface IOrderService
    {
        Task<bool> BookAsync(Order order);
        Task<IList<Order>> GetOrdersByStoreIdAsync(int storeId);
        Task<IList<Order>> GetAllOrdersAsync();
        Task<bool> AcceptBookingAsync(int orderId);
        Task<bool> DenyBookingAsync(int orderId);
    }
}
