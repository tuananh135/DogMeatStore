﻿using DogMeatStore.DataAccess.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DogMeatStore.Services.Interfaces
{
    public interface IDishService
    {
        Task<IList<Dish>> GetDishesOfStoreByStoreIdAsync(int storeId);
        Task<IList<Dish>> GetDishesOfOrderByOrderIdAsync(int orderId);
        Task<decimal> GetConsumptionCostOfOrderAsync(int orderId);
        Task<bool> AddDishesToOrderAsync(int orderId, IList<int> listDistId);
        Task<bool> RemoveDishesFromOrderAsync(int orderId, IList<int> listDistId);
    }
}
