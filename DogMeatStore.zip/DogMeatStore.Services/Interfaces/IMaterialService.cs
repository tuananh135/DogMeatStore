﻿using DogMeatStore.DataAccess.Entities;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DogMeatStore.Services.Interfaces
{
    public interface IMaterialService
    {
        Task<IList<Material>> GetReceivedMaterialsOfStoreForTheDayAsync(DateTime time, int storeId);
    }
}
